// stopka.js – losowy tekst w stopce przy każdym wejściu na stronę

(function () {
    const teksty = [
        "Numer sałatki: 666",
        "Paweł ma stulejke essa",
        "Siurek ci w oczko",
        "Żaden clanker nie ucierpiał podczas tworzenia tej strony",
        "Żaden quiz nie ucierpiał podczas tworzenia tej strony",
        "Jeśli to czytasz, to znaczy, że nie rozwiązujesz quizów",
        "Wersja strony: tak",
        "Szukaj easter eggów ;3",
        "Co tu tak wgl robisz?",
        "Ctrl + F5 nie pomoże ci w quizach",
        "ᗜˬᗜ",
        "Daj mi dostęp do swojego komputera",
        "Jestem twoim ojcem",
        "Nieoficjalnym partnerem tej oto wytryny jest: pornhub",
        "To już koniec strony, głupku. Nie wracaj tu codziennie... c-chyba że naprawdę chcesz. 💕",
        "Wesołego Femboy Friday :3 No chyba ze czytasz to w kazdy inny dzień niż piątek... To wtedy nie >:("
    ];

    function ustawStopke() {
        const element = document.getElementById("tekst-stopki");
        if (!element) return;

        const losowy = teksty[Math.floor(Math.random() * teksty.length)];
        element.textContent = losowy;
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", ustawStopke);
    } else {
        ustawStopke();
    }
})();
